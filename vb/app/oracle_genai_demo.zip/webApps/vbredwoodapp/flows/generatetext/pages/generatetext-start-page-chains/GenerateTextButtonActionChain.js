define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class GenerateTextButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.generatedText',
        ],
      });

      $page.variables.progressVar = -1;
      $page.variables.generateTextRequestVar.inferenceRequest.prompt = $page.variables.prompt;

      const callRestGenerateTextGenerateTextResult = await Actions.callRest(context, {
        endpoint: 'GenerateText/generateText',
        body: $page.variables.generateTextRequestVar,
      });

      if (callRestGenerateTextGenerateTextResult.ok) {
        $page.variables.generatedText = callRestGenerateTextGenerateTextResult.body.inferenceResponse.generatedTexts[0].text;
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error',
          message: 'Error encountered during text generation: ' + callRestGenerateTextGenerateTextResult.statuscallRestGenerateTextGenerateTextResult.status,
        });
      }

      $page.variables.progressVar = 100;
    }
  }

  return GenerateTextButtonActionChain;
});
